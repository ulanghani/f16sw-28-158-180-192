package com.example.dell.signup;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class BasicInfo extends AppCompatActivity {
    int count=0;
    String[] name=new String[]{
            "aqib",
            "noor",
            "sultan",
            "haseeb",
            "yasir",
            "adeel"


    };
    String[] rollno=new String[]{
            "F-16SW180",
            "F-16SW182",
            "F-16SW24",
            "F-16SW194",
            "F-16SW198",
            "F-16SW176"
    };
    String[] email=new String[]{
            "Aqiib.raza444@gmail.com",
            "Rockstarnoor@gmail.com",
            "m.shykh@outlook.com",
            "Haseebrao@gmail.com",
            "YasirQurshi@gmail.com",
            "Adeelsiddiqui@yahoo.com"
    };
    String[] DOB=new String[]{
            "25-07-1997",
            "28-11-1998",
            "17-07-1998",
            "02-09-1998",
            "20-05-1996",
            "02-09-1998"
    };
    int []image = new int[]{
            R.drawable.aqib,
            R.drawable.noor,
            R.drawable.sultan,
            R.drawable.haseeb,
            R.drawable.yasir,
            R.drawable.adeel
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_info);
        TextView tvname = (TextView) findViewById(R.id.textView10);
        TextView tvrollno= (TextView)findViewById(R.id.textView11);
        TextView tvemail= (TextView)findViewById(R.id.textView12);
        TextView tvdob= (TextView)findViewById(R.id.textView13);

        final TextView name1= (TextView)findViewById(R.id.textView14);
        final TextView rollno1= (TextView)findViewById(R.id.textView15);
        final  TextView email1= (TextView)findViewById(R.id.textView16);
        final TextView dob1= (TextView)findViewById(R.id.textView17);

        final ImageView img1= (ImageView) findViewById(R.id.imageView);

        Button prev= (Button) findViewById(R.id.button7);
        Button nex= (Button) findViewById(R.id.button8);

        name1.setText(name[count]);
        rollno1.setText(rollno[count]);
        email1.setText(email[count]);
        dob1.setText(DOB[count]);
        img1.setImageResource(image[count]);

        nex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count < 4) {
                    count++;
                    name1.setText(name[count]);
                    rollno1.setText(rollno[count]);
                    email1.setText(email[count]);
                    dob1.setText(DOB[count]);
                    img1.setImageResource(image[count]);
                }
            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count > 0) {
                    count--;
                    name1.setText(name[count]);
                    rollno1.setText(rollno[count]);
                    email1.setText(email[count]);
                    dob1.setText(DOB[count]);
                    img1.setImageResource(image[count]);
                }
            }
        });

    }
}
